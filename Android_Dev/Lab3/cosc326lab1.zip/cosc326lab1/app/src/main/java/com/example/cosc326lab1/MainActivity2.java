package com.example.cosc326lab1;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText tedit = (EditText) findViewById(R.id.textinput); // Corrected ID
        TextView tview = (TextView) findViewById(R.id.textoutput);

        tedit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == EditorInfo.IME_ACTION_DONE) {
                    tview.setText(tedit.getText().toString().toUpperCase());
                    return true; // Consume the event
                }
                return false; // Pass the event to other listeners
            }
        });
    }
}