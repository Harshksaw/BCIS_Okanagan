//
//  GameSPiteActionTests.swift
//  GameSPiteActionTests
//
//  Created by harsh saw on 2025-03-05.
//

import Testing
@testable import GameSPiteAction

struct GameSPiteActionTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
