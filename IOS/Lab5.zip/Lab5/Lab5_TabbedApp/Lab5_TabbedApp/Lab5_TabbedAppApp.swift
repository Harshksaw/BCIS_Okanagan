//
//  Lab5_TabbedAppApp.swift
//  Lab5_TabbedApp
//
//  Created by harsh saw on 2025-02-26.
//

import SwiftUI

@main
struct Lab5_TabbedAppApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
