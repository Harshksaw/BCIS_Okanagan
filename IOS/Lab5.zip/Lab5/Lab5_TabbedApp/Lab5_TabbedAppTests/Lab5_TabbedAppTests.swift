//
//  Lab5_TabbedAppTests.swift
//  Lab5_TabbedAppTests
//
//  Created by harsh saw on 2025-02-26.
//

import Testing
@testable import Lab5_TabbedApp

struct Lab5_TabbedAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
