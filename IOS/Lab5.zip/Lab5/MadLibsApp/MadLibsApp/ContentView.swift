import SwiftUI

struct ContentView: View {
    @State private var place: String = "Kelowna"
    @State private var verb: String = "drink"
    @State private var number: String = "12"
    @State private var story: String = ""

    @State private var showPicker = false  // State to present picker view

    var body: some View {
        VStack {
            // Labels instead of TextFields
            Text("Place: \(place)")
                .font(.title2)
                .padding()

            Text("Verb: \(verb)")
                .font(.title2)
                .padding()

            Text("Number: \(number)")
                .font(.title2)
                .padding()

            // Button to trigger the picker selection screen
            Button("Get Place, Verb and Number") {
                showPicker = true
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)

            // Button to generate the story
            Button("Create Story") {
                story = "Once upon a time in \(place), people used to \(verb) exactly \(number) times a day."
            }
            .padding()
            .background(Color.green)
            .foregroundColor(.white)
            .cornerRadius(10)

            Text(story)
                .padding()
                .multilineTextAlignment(.center)

        }
        .padding()
        .sheet(isPresented: $showPicker) {
            PickerView(selectedPlace: $place, selectedVerb: $verb, selectedNumber: $number)
        }
    }
}
