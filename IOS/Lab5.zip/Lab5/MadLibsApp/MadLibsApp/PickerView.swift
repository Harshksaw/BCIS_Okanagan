//
//  PickerView.swift
//  MadLibsApp
//
//  Created by harsh saw on 2025-02-26.
//

import SwiftUI

struct PickerView: View {
    @Binding var selectedPlace: String
    @Binding var selectedVerb: String
    @Binding var selectedNumber: String

    @Environment(\.dismiss) var dismiss  // Allows dismissing the sheet

    let places = ["Kamloops", "Kelowna", "Penticton", "Vernon"]
    let verbs = ["eat", "play", "drink", "party", "laugh"]
    let numbers = (2...20).map { "\($0)" } // Generates ["2", "3", ..., "20"]

    @State private var placeIndex = 1  // Default to "Kelowna"
    @State private var verbIndex = 2   // Default to "drink"
    @State private var numberIndex = 10 // Default to "12"

    var body: some View {
        VStack {
            Text("Choose Your Options")
                .font(.title)
                .padding()

            Picker("Select a Place", selection: $placeIndex) {
                ForEach(0..<places.count, id: \.self) { index in
                    Text(self.places[index])
                }
            }
            .pickerStyle(WheelPickerStyle())
            .frame(height: 150)

            Picker("Select a Verb", selection: $verbIndex) {
                ForEach(0..<verbs.count, id: \.self) { index in
                    Text(self.verbs[index])
                }
            }
            .pickerStyle(WheelPickerStyle())
            .frame(height: 150)

            Picker("Select a Number", selection: $numberIndex) {
                ForEach(0..<numbers.count, id: \.self) { index in
                    Text(self.numbers[index])
                }
            }
            .pickerStyle(WheelPickerStyle())
            .frame(height: 150)

            // Save selections and dismiss
            Button("Save Selection") {
                selectedPlace = places[placeIndex]
                selectedVerb = verbs[verbIndex]
                selectedNumber = numbers[numberIndex]
                dismiss()
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
    }
}
