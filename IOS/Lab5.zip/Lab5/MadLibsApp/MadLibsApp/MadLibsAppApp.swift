//
//  MadLibsAppApp.swift
//  MadLibsApp
//
//  Created by harsh saw on 13/02/25.
//

import SwiftUI

@main
struct MadLibsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
