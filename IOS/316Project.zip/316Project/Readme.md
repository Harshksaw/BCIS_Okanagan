
# Initialize Node.js project
npm init -y

# Install dependencies
npm install

# Start Node.js server
npm start

# Open TaskManager in Xcode (macOS)
open -a Xcode TaskManager.xcodeproj