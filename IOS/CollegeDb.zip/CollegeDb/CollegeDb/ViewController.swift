//
//  ViewController.swift
//  CollegeDb
//
//  Created by harsh saw on 2025-03-07.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

