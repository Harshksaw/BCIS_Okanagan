//
//  CollegeDbTests.swift
//  CollegeDbTests
//
//  Created by harsh saw on 2025-03-07.
//

import Testing
@testable import CollegeDb

struct CollegeDbTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
