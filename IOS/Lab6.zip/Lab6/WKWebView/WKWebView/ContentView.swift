//
//  ContentView.swift
//  WKWebView
//
//  Created by harsh saw on 2025-03-03.
//
import UIKit
import WebKit

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
