//
//  WKWebViewApp.swift
//  WKWebView
//
//  Created by harsh saw on 2025-03-03.
//

import SwiftUI

@main
struct WKWebViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
