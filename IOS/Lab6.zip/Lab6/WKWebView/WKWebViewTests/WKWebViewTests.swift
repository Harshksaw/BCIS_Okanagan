//
//  WKWebViewTests.swift
//  WKWebViewTests
//
//  Created by harsh saw on 2025-03-03.
//

import Testing
@testable import WKWebView

struct WKWebViewTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
