Created BY -Harsh and Allen
<!-- Run step by step -->

docker build -t ghostchat .
docker run -p 5001:5000 ghostchat





Run atleast two of these in two terminal
javac -d out src/*.java src/utils/*.java
java -cp out Client


